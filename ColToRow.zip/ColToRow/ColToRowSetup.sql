create table col_to_row
(
  key varchar2(3) ,
  c1  varchar2(5) ,
  c2  varchar2(5) ,
  c3  varchar2(5) ,
  n1  number
);

insert into  col_to_row  values ( 'r1' , 'v1' , 'v2' , 'v3', 1  );
insert into  col_to_row  values ( 'r2' , 'v1' , 'v2' , null, 2  );
insert into  col_to_row  values ( 'r3' , 'v1' , null , 'v3', 3  );
insert into  col_to_row  values ( 'r4' , 'v1' , null , null, 4  );
insert into  col_to_row  values ( 'r5' , null , 'v2' , 'v3', 5  );
insert into  col_to_row  values ( 'r6' , null , 'v2' , null, 6  );
insert into  col_to_row  values ( 'r7' , null , null , 'v3', 7  );
insert into  col_to_row  values ( 'r8' , null , null , null, 8  );

commit;

create type name_value_pair as object( name varchar2(30), value varchar2(5) );
/

create type name_value_varray as varray(10) of name_value_pair ;
/

create type varray_type as varray(10) of varchar2(5);
/

