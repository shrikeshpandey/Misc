select key, c1, c2, c3 from col_to_row order by key ;
/*desc name_value_pair
 Name                          Null?    Type
 ----------------------------- -------- --------------------
 NAME                                   VARCHAR2(30)
 VALUE                                  VARCHAR2(5)


desc name_value_varray
 name_value_varray VARRAY(10) OF NAME_VALUE_PAIR
 Name                          Null?    Type
 ----------------------------- -------- --------------------
 NAME                                   VARCHAR2(30)
 VALUE                                  VARCHAR2(5)

*/
select
  key ,
  VALS.NAME  as source ,
  VALS.VALUE as val
from  col_to_row ,  table  ( NAME_VALUE_VARRAY
    ( NAME_VALUE_PAIR( 'C1', col_to_row.c1 ),
      NAME_VALUE_PAIR( 'C2', col_to_row.c2 ),
      NAME_VALUE_PAIR( 'C3', col_to_row.c3 )
    )
  ) vals
order by
  key, source
;

/*desc varray_type
 varray_type VARRAY(10) OF VARCHAR2(5)*/
 
select key, VALS.COLUMN_VALUE as val
from   col_to_row, table( VARRAY_TYPE( col_to_row.c1, col_to_row.c2, col_to_row.c3 ) ) vals
order by key ;

select
  key ,
  'C' || ROW_NUMBER () OVER (PARTITION BY KEY ORDER BY 1) as source ,
  vals.column_value as val
from
  col_to_row , table( varray_type( col_to_row.c1, col_to_row.c2, col_to_row.c3 ) ) vals;
-------------------------------------------------------------------------
-------------------------------------------------------------------------
select key, source, val
from   col_to_row
model
  return updated rows
  partition by ( key )
  dimension by ( 0 as i )
  measures     ( 'xx' as source, 'xxxxx' as val, c1, c2, c3 )
  rules upsert all
  ( source[ 1 ] = 'C1' ,  source[ 2 ] = 'C2' , source[ 3 ] = 'C3' ,
    val[ 1 ] = c1[ 0 ] ,  val[ 2 ] = c2[ 0 ] , val[ 3 ] = c3[ 0 ] )
order by key, source ;

-----------------------------------------------------------------------
--=====================================================================


