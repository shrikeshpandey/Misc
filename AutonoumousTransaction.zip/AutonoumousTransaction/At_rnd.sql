CREATE TABLE test_autonomous1 (
 colA VARCHAR2(100),
 colB VARCHAR2(100) );

CREATE OR REPLACE PROCEDURE TEST_AUTO1 IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN

for i in (SELECT * from test_autonomous1)
loop

INSERT INTO test_autonomous1
VALUES(i.colA,'Part of main commited transaction '||i.colb);

end loop;

INSERT INTO test_autonomous1
VALUES('Autonomous Transaction',2);
COMMIT;
END TEST_AUTO1;
/
SELECT *
FROM test_autonomous1;

DECLARE
BEGIN
INSERT INTO test_autonomous1
VALUES('Main Transaction',1);
-- call the autonomous transaction
Test_Auto();
-- rollback the main transaction
Commit;
--ROLLBACK;
END;
/



SELECT *
FROM test_autonomous1;


