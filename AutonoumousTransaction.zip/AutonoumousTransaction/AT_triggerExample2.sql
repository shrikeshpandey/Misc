insert into x_short (val, b_default) values (1, 0);
insert into x_short (val, b_default) values (2, -1);

commit;
select * from x_short;

insert into x_short (val, b_default) values (3, -1);
commit;

select * from x_short;

insert into x_short (val, b_default) values (4, -1);

rollback;

select * from x_short;

truncate table x_short;

insert into x_short (val, b_default) values (1, -1);
insert into x_short (val, b_default) values (2, 0);

 commit;

select * from x_short;

update x_short set b_default = -1 where val = 2;
commit;

select * from x_short;
update x_short set b_default = -1 where val = 1;

rollback;

select * from x_short;


