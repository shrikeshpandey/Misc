CREATE TABLE x_short
  (pk                             VARCHAR2(32) NOT NULL primary key,
   val                            NUMBER,
   b_default                      NUMBER(1))
/
CREATE OR REPLACE TRIGGER tbi_short
  BEFORE INSERT
  ON x_short
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  declare
    pragma autonomous_transaction;
  begin
    -- if creating a new default then set all other default(s) false
    if (:new.b_default = -1) then
      update x_short set b_default = 0 where b_default = -1;
      commit;
    end if;
   -- generate pk
    if :new.pk is null then
      execute immediate 'select sys_op_guid() from dual ' into :new.pk;
    end if;

  End;
  /
CREATE OR REPLACE TRIGGER tbu_short
 BEFORE UPDATE
  ON x_short
  REFERENCING NEW AS NEW OLD AS OLD
  FOR EACH ROW
  declare
    pragma autonomous_transaction;
  begin

    if (:new.b_default = -1) then
      update x_short set b_default = 0 where b_default = -1;
      commit;
    end if;

  end;
  /






