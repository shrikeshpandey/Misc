CREATE TABLE test_autonomous (
 colA VARCHAR2(100) );

CREATE OR REPLACE PROCEDURE Test_Auto IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
INSERT INTO test_autonomous
VALUES('Autonomous Transaction');
COMMIT;
END Test_Auto;
/
SELECT *
FROM test_autonomous;

DECLARE
BEGIN
INSERT INTO test_autonomous
VALUES('Main Transaction');
-- call the autonomous transaction
Test_Auto();
-- rollback the main transaction
Commit;
--ROLLBACK;
END;
/



SELECT *
FROM test_autonomous;


