--Case 1

DECLARE
BEGIN
INSERT INTO test_autonomous1
VALUES('Main Transaction','Started '||1);
-- call the autonomous transaction
Commit;

Test_Auto1();
-- rollback the main transaction
--Commit;
ROLLBACK;

END;

--truncate table test_autonomous1
select * from test_autonomous1
