select * from  hier_data
/
/*To connect and order the data in this table using the PARENT_KEY hierarchy
 we can create a Hierarchical Query using the START WITH and CONNECT BY clauses of the 
 SELECT command. START WITH identifies 
the topmost rows in the hierarchy. CONNECT BY identifies all subsequent rows in the hierarchy.
The PRIOR operator in hierarchical queries gives us access to column information from 
the parent of the current row. It can be used outside the CONNECT BY clause if required. 

*/
select  key ,  level
from  hier_data
START WITH parent_key is null
CONNECT BY  parent_key = prior key
/
/*The LEVEL pseudocolumn in the previous result indicates which 
level in the hierarchy each row is at. The topmost level is assigned a LEVEL of 1. 
To better illustrate hierarchical relationships the
 LEVEL column is commonly used to indent selected values, like this.*/
select
  lpad( ' ', level-1 ) || key as key_indented ,
  level
from hier_data
START WITH  parent_key is null
CONNECT BY  parent_key = prior key
/
/**/
select
  lpad( ' ', level-1 ) || key as key_indented ,
  level
from
hier_data
START WITH
  KEY = 'delx'
connect by
  key = PRIOR PARENT_KEY
;
/*Hierarchical Data
Order of Operations
The clauses in hierarchical queries are processed in the following order. 

1 join conditions (either in the FROM clause or the WHERE clause) 
2 START WITH clause 
3 CONNECT BY clause 
4 WHERE clause conditions that are not joins. 
The following two snippets demonstrate how this order of operations affects query results when filter conditions are in the WHERE clause versus when they are in the CONNECT BY clause. 

*/
 
