create table Hier_data
( key        varchar2(10) ,
  parent_key varchar2(10) ,
  name       varchar2(10)
);

insert into Hier_data values ( 'nls'   , null     , 'NLS'    );
insert into  Hier_data  values ( 'demo'  , 'nls'    , 'DATA'   );
insert into  Hier_data  values ( 'mesg'  , 'nls'    , 'DEMO'   );

insert into  Hier_data  values ( 'server', null     , 'SERVER' );
insert into  Hier_data  values ( 'bin'   , 'server' , 'BIN'    );
insert into  Hier_data  values ( 'config', 'server' , 'CONFIG' );
insert into  Hier_data  values ( 'log'   , 'config' , 'LOG'    );
insert into  Hier_data  values ( 'ctx'   , 'server' , 'CTX'    );
insert into  Hier_data  values ( 'admin' , 'ctx'    , 'ADMIN'  );
insert into  Hier_data  values ( 'data'  , 'ctx'    , 'DATA'   );
insert into  Hier_data  values ( 'delx'  , 'data'   , 'DELX'   );
insert into  Hier_data  values ( 'enlx'  , 'data'   , 'ENLX'   );
insert into  Hier_data  values ( 'eslx'  , 'data'   , 'ESLX'   );
insert into  Hier_data  values ( 'mig'   , 'ctx'    , 'MESG'   );

commit;

column level       format 99999
column key_indented  format a15
column root_key    format a10
column root_name   format a10
column key_path    format a25
column name_path   format a25

set null '(null)'

variable v_target_key varchar2(10)
