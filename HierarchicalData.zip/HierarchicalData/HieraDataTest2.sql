/*CONNECT_BY_ISLEAF
The CONNECT_BY_ISLEAF pseudocolumn returns 1 if the current row is a leaf of the tree defined 
by the CONNECT BY condition, 0 otherwise. 

*/

select
  lpad(' ', level-1 ) || key as key_indented ,
  CONNECT_BY_ISLEAF
from  Hier_data
start with
  key = 'server'
connect by
  parent_key = prior key
;
/*CONNECT_BY_ROOT
The CONNECT_BY_ROOT operator returns column information from the root row of the hierarchy. 

*/
select
  lpad(' ', level-1 ) || key as key_indented ,
  level ,
  key ,
  name ,
  CONNECT_BY_ROOT key        as root_key   ,
  CONNECT_BY_ROOT name       as root_name
from
  Hier_data
start with
  parent_key is null
connect by
  parent_key = prior key;
  
  /*SYS_CONNECT_BY_PATH
The SYS_CONNECT_BY_PATH function returns a single string containing all the column values 
encountered in the path from root to node. 
*/
select
  lpad(' ', level-1 ) || key        as key_indented ,
  name ,
  SYS_CONNECT_BY_PATH( key , '/' )  as key_path   ,
  SYS_CONNECT_BY_PATH( name, '/' )  as name_path
from
  hier_data
start with
  parent_key is null
connect by
  parent_key = prior key;

