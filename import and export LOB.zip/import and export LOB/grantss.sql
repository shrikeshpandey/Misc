EXEC DBMS_JAVA.grant_permission('RND', 'java.io.FilePermission', 'E:\OraDir', 'read ,write, execute, delete');
EXEC Dbms_Java.Grant_Permission('RND', 'SYS:java.lang.RuntimePermission', 'writeFileDescriptor', '');
EXEC Dbms_Java.Grant_Permission('RND', 'SYS:java.lang.RuntimePermission', 'readFileDescriptor', '');