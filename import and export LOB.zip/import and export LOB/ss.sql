DECLARE
  l_bfile  BFILE;
  l_clob   CLOB;
BEGIN
  INSERT INTO tab1 (col1)
  VALUES (empty_clob())
  RETURN col1 INTO l_clob;

  l_bfile := BFILENAME('DOCUMENTS', 'Sample.txt');
  DBMS_LOB.fileopen(l_bfile, DBMS_LOB.file_readonly);
  DBMS_LOB.loadfromfile(l_clob, l_bfile, DBMS_LOB.getlength(l_bfile));
  DBMS_LOB.fileclose(l_bfile);

  COMMIT;
END;
