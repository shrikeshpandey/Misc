create table group_by_test
( grp_a varchar2(10)
, grp_b varchar2(10)
, grp_c varchar2(10)
, grp_d varchar2(10)
, val   number
) ;

insert into group_by_test values ( 'a1' , 'b1' , 'c1', 'd1', '10' ) ;
insert into group_by_test values ( 'a1' , 'b1' , 'c1', 'd1', '20' ) ;
insert into group_by_test values ( 'a1' , 'b2' , 'c1', 'd1', '30' ) ;
insert into group_by_test values ( 'a1' , 'b2' , 'c1', 'd1', '40' ) ;
insert into group_by_test values ( 'a1' , 'b2' , 'c2', 'd1', '50' ) ;
insert into group_by_test values ( 'a2' , 'b3' , 'c2', 'd2', '12' ) ;
insert into group_by_test values ( 'a2' , 'b3' , 'c2', 'd2', '22' ) ;
insert into group_by_test values ( 'a2' , 'b3' , 'c2', 'd2', '32' ) ;

commit ;

create table group_by_test2
( grp_a varchar2(10)
, grp_b varchar2(10)
, val   number
) ;

insert into group_by_test2 values ( 'A1' , 'X1' , '10' ) ;
insert into  group_by_test2 values ( 'A1' , 'X2' , '40' ) ;
insert into  group_by_test2 values ( 'A1' , null , '20' ) ;
insert into  group_by_test2 values ( 'A1' , null , '30' ) ;
insert into  group_by_test2 values ( 'A1' , null , '50' ) ;
insert into  group_by_test2 values ( 'A2' , null , '60' ) ;

commit ;
