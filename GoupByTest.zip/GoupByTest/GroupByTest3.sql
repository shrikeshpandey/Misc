/*It often happens that a query will have a group A which is a superset of group B which in turn is a superset of group C. When aggregates are required at each level a query like this can be used. 

*/
select * from group_by_test
select
  grp_a
, grp_b
, grp_c
, count(*)
from   group_by_test
group by  grouping sets
  (( grp_a, grp_b, grp_c ) , ( grp_a, grp_b )  , ( grp_a )  , ()  )
order by  1, 2, 3;
/*This arrangement is common enough that SQL actually provides a shortcut for specifying these types of GROUPING SETS clauses. It uses the ROLLUP operator. Here is how the query above looks when implemented with ROLLUP. 

*/

select
  grp_a
, grp_b
, grp_c
, count(*)
from  group_by_test
group by
  ROLLUP( GRP_A, GRP_B, GRP_C )
order by  1, 2, 3;
