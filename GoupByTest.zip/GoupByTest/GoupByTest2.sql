/*GROUP_ID
Unlike a regular GROUP BY clause, including the same column more than once in a GROUPING SETS clause produces duplicate rows. 
select grp_a, count(*)
from   group_by_test
GROUP BY GROUPING SETS ( GRP_A, GRP_A )
order by grp_a ;
 
The GROUP_ID function can be used to distinguish duplicates from each other. 


*/

select grp_a, count(*), GROUP_ID()
from   group_by_test
GROUP BY GROUPING SETS ( GRP_A, GRP_A, GRP_A )
order by grp_a, group_id() ;
/*there would be little practical use for GROUP_ID. There are times when more complex GROUP BY clauses can return duplicate rows however. It is in such queries that GROUP_ID proves useful. 

Note that GROUP_ID will always be 0 in a result set that contains no duplicates. 

*/
