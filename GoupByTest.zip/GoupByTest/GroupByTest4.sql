/*There are times when all combinations of a collection of grouping columns are required, as in this query. 

*/
select
  grp_a
, grp_b
, grp_c
, count(*)
from group_by_test
group by  grouping sets
  (( grp_a, grp_b, grp_c ) , ( grp_a, grp_b )
  , ( grp_a, grp_c )  , ( grp_b, grp_c )  , ( grp_a )
  , ( grp_b )  , ( grp_c )  , ()  )
order by  1, 2, 3
/*This arrangement is common enough that SQL provides a shortcut called the CUBE operator to implement it. Here is how the query above looks after re-writing it to use CUBE. 
*/
select
  grp_a
, grp_b
, grp_c
, count(*)
from  group_by_test
group by
  CUBE( GRP_A, GRP_B, GRP_C )
order by  1, 2, 3;
 
