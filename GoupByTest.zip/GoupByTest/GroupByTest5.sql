select  TO_CHAR( GROUPING( GRP_A ) ) || TO_CHAR( GROUPING( GRP_B ) ) AS BIT_VECTOR,
  DECODE  ( TO_CHAR( GROUPING( GRP_A ) )  || TO_CHAR( GROUPING( GRP_B ) )
  , '01', 'Group "' || GRP_A || '" Total'
  , '10', 'Group "' || GRP_B || '" Total'
  , '11', 'Grand Total'
  , NULL
  ) AS LABEL
,
  count(*)
from
  group_by_test2
group by
  grouping sets ( grp_a, grp_b, ()  )
order by
  GROUPING( GRP_A )
, grp_a
, GROUPING( GRP_B )
, grp_b
;


-----------
select
  DECODE
  ( GROUPING_ID( GRP_A, GRP_B )
  , 1, 'Group "' || GRP_A || '" Total'
  , 2, 'Group "' || GRP_B || '" Total'
  , 3, 'Grand Total'
  , NULL
  ) AS LABEL
, count(*)
from
  t2
group by
  grouping sets ( grp_a, grp_b, ()  )
order by
  GROUPING_ID( GRP_A, GRP_B )
, grp_a
, grp_b
;

