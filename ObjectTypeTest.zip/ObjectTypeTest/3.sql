  declare
    ------ constructor function typ_emp1 return self as result,
      t_emp1  typ_emp1 := typ_emp1(7369,'SMITH','CLERK',7902,to_date('17/12/1980','dd/mm/rrrr'),'800.00',NULL,20) ;
    ---constructor function typ_emp1 (p_empno number,p_ename varchar2) return self as result,
      t_emp2  typ_emp1 := typ_emp1(7499,'ALLEN') ;
    --- constructor function typ_emp1 (p_empno number,p_hiredate date,p_deptno number) return self as result,
      t_emp3  typ_emp1 := typ_emp1(7369,to_date('17/12/1980','dd/mm/rrrr'),20) ;
    --- constructor function typ_emp1 (p_ename varchar2,p_job varchar2,p_deptno number) return self as result,
      t_emp4  typ_emp1 := typ_emp1('SMITH','CLERK',20) ;
    --- member function display RETURN VARCHAR2
  begin
    ------ constructor function typ_emp1 return self as result,
      DBMS_OUTPUT.PUT_LINE( 't_emp1.ename    = [' || t_emp1.ename || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp1.hiredate = [' || t_emp1.hiredate || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp1.deptno   = [' || t_emp3.deptno || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp1.deptno   = [' || t_emp3.display || ']' );
   ---constructor function typ_emp1 (p_empno number,p_ename varchar2) return self as result,
      DBMS_OUTPUT.PUT_LINE( 't_emp2.ename    = [' || t_emp2.ename || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.hiredate = [' || t_emp2.hiredate || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.deptno   = [' || t_emp2.deptno || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.deptno   = [' || t_emp2.display || ']' );
   
   --- constructor function typ_emp1 (p_empno number,p_hiredate date,p_deptno number) return self as result,
      DBMS_OUTPUT.PUT_LINE( 't_emp2.ename    = [' || t_emp3.ename || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.hiredate = [' || t_emp3.hiredate || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.deptno   = [' || t_emp3.deptno || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.deptno   = [' || t_emp3.display || ']' );

   --- constructor function typ_emp1 (p_ename varchar2,p_job varchar2,p_deptno number) return self as result,
      DBMS_OUTPUT.PUT_LINE( 't_emp2.ename    = [' || t_emp4.ename || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.hiredate = [' || t_emp4.hiredate || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.deptno   = [' || t_emp4.deptno || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp2.deptno   = [' || t_emp4.display || ']' );

    --- member function display RETURN VARCHAR2
   
  end;    
