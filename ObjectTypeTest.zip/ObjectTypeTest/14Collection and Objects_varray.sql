/*A varray is an ordered set of data elements. All elements of a given varray are of the
same datatype or a subtype of the declared one. Each element has an index, which is a
number corresponding to the element's position in the array. The index number is used
to access a specific element.
When you define a varray, you specify the maximum number of elements it can
contain, although you can change this number later. The number of elements in an
array is the size of the array. Oracle allows arrays to be of variable size, which is why
they are called varrays.
*/

CREATE TYPE email_list_arr AS VARRAY(10) OF VARCHAR2(80);

CREATE TYPE phone_typ AS OBJECT (
country_code VARCHAR2(2),
area_code VARCHAR2(3),
ph_number VARCHAR2(7));
/
CREATE TYPE phone_varray_typ AS VARRAY(5) OF phone_typ;
/
CREATE TABLE dept_phone_list (
dept_no NUMBER(5),
phone_list phone_varray_typ);

INSERT INTO dept_phone_list VALUES (
100,
phone_varray_typ( phone_typ ('01', '650', '5061111'),
phone_typ ('01', '650', '5062222'),
phone_typ ('01', '650', '5062525')));
