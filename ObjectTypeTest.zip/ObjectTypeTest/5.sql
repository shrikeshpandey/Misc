CREATE TABLE t_emp_dept1
  ( number_column NUMBER
  , typ_emp1_col typ_emp1
  , typ_dept_col typ_dept  );

/
  SELECT ROWNUM
    ,      typ_emp1(empno,ename,job,mgr,HIREDATE,SAL,COMM,e.deptno )
    ,      typ_dept(d.deptno, d.dname,d.loc)
    FROM   emp e,dept d
    where  e.deptno=d.deptno

/
INSERT INTO t_emp_dept1
     SELECT ROWNUM
    ,      typ_emp1(empno,ename,job,mgr,HIREDATE,SAL,COMM,e.deptno )
    ,      typ_dept(d.deptno, d.dname,d.loc)
    FROM   emp e,dept d
    where  e.deptno=d.deptno
/
select * from t_emp_dept1
/
