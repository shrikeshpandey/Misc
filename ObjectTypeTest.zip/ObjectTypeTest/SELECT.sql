select * from emp
/
select typ_emp(empno,ename,job,mgr,HIREDATE,SAL,COMM,deptno ) from emp
/
select * from dept
/
select typ_dept(d.deptno, d.dname,d.loc) from dept d
/
select * from salgrade
/
select typ_salgrade(GRADE,LOSAL,HISAL) from salgrade
/
