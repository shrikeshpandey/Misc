  declare
      t_emp  typ_emp := typ_emp(7369,'SMITH','CLERK',7902,to_date('17/12/1980','dd/mm/rrrr'),'800.00',NULL,20) ;
  begin
      DBMS_OUTPUT.PUT_LINE( 't_emp.ename    = [' || t_emp.ename || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp.hiredate = [' || t_emp.hiredate || ']' );
      DBMS_OUTPUT.PUT_LINE( 't_emp.deptno   = [' || t_emp.deptno || ']' );
  end;    
