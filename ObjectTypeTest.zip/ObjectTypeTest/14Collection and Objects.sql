﻿-----Support for Collection Datatypes

/*Creating Collection Datatypes
 Oracle supports the varray and nested table collection datatypes.
 ■ A varray is an ordered collection of elements
 ■ A nested table can have any number of elements
 If you need to store only a fixed number of items, or to loop through the elements in
 order, or you will often want to retrieve and manipulate the entire collection as a
 value, then use a varray.
If you need to run efficient queries on a collection, handle arbitrary numbers of
elements, or perform mass insert, update, or delete operations, then use a nested table.*/
CREATE OR REPLACE TYPE person_typ AS OBJECT (
idno NUMBER,
name VARCHAR2(30),
phone VARCHAR2(20),
MAP MEMBER FUNCTION get_idno RETURN NUMBER,
MEMBER PROCEDURE display_details ( SELF IN OUT NOCOPY person_typ ) )
/
CREATE TYPE people_typ AS TABLE OF person_typ;
/
CREATE TABLE people_tab (
       group_no NUMBER,
       people_column people_typ )
 NESTED TABLE people_column STORE AS people_column_nt;
/
INSERT INTO people_tab VALUES (
100,
people_typ( person_typ(1, 'John Smith', '1-800-555-1212'),
person_typ(2, 'Diane Smith', NULL)));
/
INSERT INTO people_tab
 select e.department_id,cast(multiset(select distinct b.employee_id,b.first_name||' '||b.last_name,b.phone_number from employees b where b.department_id=e.department_id) as people_typ )  
     as people_typ
     from departments e 
     
CREATE TABLE department_persons (
dept_no NUMBER PRIMARY KEY,
dept_name CHAR(20),
dept_mgr person_typ DEFAULT person_typ(10,'John Doe',NULL),
dept_emps people_typ DEFAULT people_typ() )
NESTED TABLE dept_emps STORE AS dept_emps_tab;

INSERT INTO department_persons VALUES
( 101, 'Physical Sciences', person_typ(65,'Vrinda Mills', '1-800-555-4412'),
people_typ( person_typ(1, 'John Smith', '1-800-555-1212'),
person_typ(2, 'Diane Smith', NULL) ) );

INSERT INTO department_persons VALUES
( 104, 'Life Sciences', person_typ(70,'James Hall', '1-800-555-4621'),
people_typ() );

---- Query on nested object e.g. people_tab
select * from people_tab t
/
select * from people_tab t,table(t.people_column) e
/
SELECT *
FROM department_persons d
/
SELECT e.*
FROM department_persons d, TABLE(d.dept_emps) e
/
SELECT d.dept_no, e.*
FROM department_persons d, TABLE(d.dept_emps) e
/
--To get rows for departments that have no employees, you can use outer-join syntax:
SELECT d.dept_no, e.*
FROM department_persons d, TABLE(d.dept_emps) (+) e
/
---Using a Table Expression Containing a Subquery of a Collection
SELECT *
FROM TABLE(SELECT d.dept_emps
FROM department_persons d
WHERE d.dept_no = 101)
/*There are these restrictions on using a subquery in a TABLE expression:
1 The subquery must return a collection type
2 The SELECT list of the subquery must contain exactly one item
3 The subquery must return only a single collection; it cannot return collections for
multiple rows. For example, the subquery SELECT dept_emps FROM
department_persons succeeds in a TABLE expression only if table
department_persons contains just a single row. If the table contains more than
one row, the subquery produces an error.*/
/
--Using a Table Expression in a CURSOR Expression,

SELECT d.dept_no, CURSOR(SELECT * FROM TABLE(d.dept_emps))
FROM department_persons d
WHERE d.dept_no = 101;

/
/*Performing DML Operations on Collections
Oracle supports the following DML operations on nested table columns:
�� Inserts and updates that provide a new value for the entire collection
�� Piecewise Updates
�� Inserting new elements into the collection
�� Deleting elements from the collection
�� Updating elements of the collection.
Oracle does not support piecewise updates on VARRAY columns. However, VARRAY
columns can be inserted into or updated as an atomic unit.
For piecewise updates of nested table columns, the DML statement identifies the
nested table value to be operated on by using the TABLE expression.*/

INSERT INTO TABLE(SELECT d.dept_emps
FROM department_persons d
WHERE d.dept_no = 101)
VALUES (5, 'Kevin Taylor', '1-800-555-6212')
/
UPDATE TABLE(SELECT d.dept_emps
FROM department_persons d
WHERE d.dept_no = 101) e
SET VALUE(e) = person_typ(5, 'Kevin Taylor', '1-800-555-6233')
WHERE e.idno = 5;
/
DELETE FROM TABLE(SELECT d.dept_emps
FROM department_persons d
WHERE d.dept_no = 101) e
WHERE e.idno = 5;
/
/*Member of a Nested Table Comparison
The MEMBER [OF] or NOT MEMBER [OF] condition tests whether an element is a
member of a nested table, returning the result as a Boolean value. The OF keyword is
optional and has no effect on the output.*/
--- Using MEMBER OF on a Nested Table*/

select * from people_tab
where person_typ(1,'John Smith','1-800-555-1212') MEMBER OF people_column
/
/*Empty Comparison
The IS [NOT] EMPTY condition checks whether a given nested table is empty or not
empty, regardless of whether any of the elements are NULL. If a NULL is given for the
nested table, the result is NULL. The result is returned as a Boolean value.
*/
-- Using IS NOT on a Nested Table
select * from people_tab t, table(t.people_column)
where people_column IS NOT EMPTY
/
SELECT *
FROM department_persons d,table(d.dept_emps)
where dept_emps IS NOT EMPTY

/*Set Comparison
The IS [NOT] A SET condition checks whether a given nested table is composed of
unique elements, returning a Boolean value.
*/
--- Using IS A SET on a Nested Table
select * from people_tab t, table(t.people_column)
where people_column IS A SET
/
SELECT *
FROM department_persons d,table(d.dept_emps)
where dept_emps IS A SET
/
/*CARDINALITY
The CARDINALITY function returns the number of elements in a varray or nested
table. The return type is NUMBER. If the varray or nested table is a null collection, NULL
is returned*/.
--- Determining the CARDINALITY of a Nested Table
SELECT t.group_no,t.people_column,CARDINALITY(t.people_column)
FROM people_tab t;
/*SET
The SET function converts a nested table into a set by eliminating duplicates, and
returns a nested table whose elements are DISTINCT from one another. The nested
table returned is of the same named type as the input nested table.*/
--- Using the SET Function on a Nested Table
SELECT SET(t.people_column)
FROM people_tab t
WHERE t.group_no = 50;
