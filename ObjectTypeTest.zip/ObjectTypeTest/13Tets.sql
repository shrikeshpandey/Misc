﻿------------------Functions and Operators Useful with Objects

---------/*   Several functions and operators are particularly useful for working with objects and
---------references to objects:
-----■ CAST
-----■ CURSOR
-----■ DEREF
-----■ IS OF type
-----■ REF
-----■ SYS_TYPEID
-----■ TABLE()
-----■ TREAT
-----■ VALUE
-------------------------------------------------------------------
-----------Using the CAST Function
CREATE TYPE person_list_typ AS TABLE OF person_typ;
/
select * from contacts;

SELECT CAST(COLLECT(contact) AS person_list_typ)
FROM contacts;
