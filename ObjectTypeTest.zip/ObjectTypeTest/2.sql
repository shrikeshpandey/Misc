CREATE OR REPLACE TYPE "SHRI"."TYP_EMP1" as object
(
  EMPNO NUMBER(4,0),
  ENAME VARCHAR2(10),
  JOB VARCHAR2(9),
  MGR NUMBER(4,0),
  HIREDATE DATE,
  SAL NUMBER(7,2),
  COMM NUMBER(7,2),
  DEPTNO NUMBER(2,0),

constructor function typ_emp1 return self as result,
constructor function typ_emp1 (p_empno number,p_ename varchar2) return self as result,
constructor function typ_emp1 (p_empno number,p_hiredate date,p_deptno number) return self as result,
constructor function typ_emp1 (p_ename varchar2,p_job varchar2,p_deptno number) return self as result,
member function display RETURN VARCHAR2

)
/
CREATE OR REPLACE TYPE BODY TYP_EMP1 as

  constructor function typ_emp1
   return self as result
  is
  begin
    return;
  end;

  constructor function typ_emp1 (p_empno number,p_ename varchar2)
   return self as result
  is
  begin
    self.empno :=p_empno;
    self.ename:=p_ename;
    return;

  end;

  constructor function typ_emp1 (p_empno number,p_hiredate date,p_deptno number)
   return self as result
  is
  begin
    self.empno:=p_empno;
    self.hiredate:=p_hiredate;
    self.deptno:=p_deptno;
    return;

  end;

  constructor function typ_emp1 (p_ename varchar2,p_job varchar2,p_deptno number)
   return self as result
  is
  begin

  self.EMPNO :=NULL;
  self.ENAME:=p_ename;
  self.JOB :=p_job;
  self.MGR :=NULL;
  self.HIREDATE :=to_date('01/01/2010','dd/mm/rrrr');
  self.SAL :=0;
  self.COMM :=0;
  self.DEPTNO :=p_deptno;
  return;

  end;
 
  member function display RETURN VARCHAR2
  is
  begin
    return '['||self.EMPNO ||']['||
                self.ENAME ||']['||
                self.JOB ||']['||
                self.MGR ||']['||
                self.HIREDATE ||']['||
                self.SAL ||']['||
                self.COMM ||']['||
                self.DEPTNO ||']' ;
 END;
  end;
/
