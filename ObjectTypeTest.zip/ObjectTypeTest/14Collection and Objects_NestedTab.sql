/*A nested table is an unordered set of data elements, all of the same datatype. No
maximum is specified in the definition of the table and the order of the elements is not
preserved. You select, insert, delete, and update in a nested table just as you do with
ordinary tables using the TABLE expression.
Elements of a nested table are actually stored in a separate storage table that contains a
column that identifies the parent table row or object to which each element belongs. A
nested table has a single column, and the type of that column is a built-in type or an
object type. If the column in a nested table is an object type, the table can also be
viewed as a multi-column table, with a column for each attribute of the object type.*/

---Creating and Populating Simple Nested Tables
CREATE TABLE students (
graduation DATE,
math_majors people_typ,
chem_majors people_typ,
physics_majors people_typ)
NESTED TABLE math_majors STORE AS math_majors_nt
NESTED TABLE chem_majors STORE AS chem_majors_nt
NESTED TABLE physics_majors STORE AS physics_majors_nt;

CREATE INDEX math_idno_idx ON math_majors_nt(idno);

CREATE INDEX chem_idno_idx ON chem_majors_nt(idno);

CREATE INDEX physics_idno_idx ON physics_majors_nt(idno);

INSERT INTO students (graduation) VALUES ('01-JUN-03');

UPDATE students
SET math_majors =
people_typ (person_typ(12, 'Bob Jones', '111-555-1212'),
person_typ(31, 'Sarah Chen', '111-555-2212'),
person_typ(45, 'Chris Woods', '111-555-1213')),
chem_majors =
people_typ (person_typ(51, 'Joe Lane', '111-555-1312'),
person_typ(31, 'Sarah Chen', '111-555-2212'),
person_typ(52, 'Kim Patel', '111-555-1232')),
physics_majors =
people_typ (person_typ(12, 'Bob Jones', '111-555-1212'),
person_typ(45, 'Chris Woods', '111-555-1213'))
WHERE graduation = '01-JUN-03';
