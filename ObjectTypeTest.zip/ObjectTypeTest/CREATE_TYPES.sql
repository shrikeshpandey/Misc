create type typ_emp as object
(
  EMPNO NUMBER(4,0), 
  ENAME VARCHAR2(10), 
  JOB VARCHAR2(9), 
  MGR NUMBER(4,0), 
  HIREDATE DATE, 
  SAL NUMBER(7,2), 
  COMM NUMBER(7,2), 
  DEPTNO NUMBER(2,0)
);

create type typ_dept as object
(
  DEPTNO NUMBER(2,0), 
	DNAME VARCHAR2(14), 
	LOC VARCHAR2(13)
  );

create type typ_bonus as object
(
  ENAME VARCHAR2(10), 
	JOB VARCHAR2(9), 
	SAL NUMBER, 
	COMM NUMBER
  );

create type typ_salgrade as object
(
  GRADE NUMBER, 
	LOSAL NUMBER, 
	HISAL NUMBER
)

