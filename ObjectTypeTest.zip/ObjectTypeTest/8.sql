DECLARE

    spt_emp1     supertype_emp;
    spt_emp2     supertype_emp;
    spt_emp3     supertype_emp;
    spt_ed       superT_dept;

---Overloaded procedure    
  PROCEDURE OutPutPrint (p in supertype_emp)
    IS
    BEGIN
      DBMS_OUTPUT.PUT_LINE(p.print);
    END;
    
  PROCEDURE OutPutPrint (p in superT_dept)
    IS
    BEGIN
      DBMS_OUTPUT.PUT_LINE(p.display);
    END;
----------------------    
    
    
BEGIN   

  spt_emp1:=subt_emp(7369,'SMITH',20,800);
  spt_emp2:=SUBT_EMP_DEPT(7369,'SMITH','RESEARCH',NULL,to_date('17/12/1980','dd/mm/rrrr'));
  spt_emp3:=SUBT_EMP_DEPT(NULL,'SMITH','RESEARCH',NULL,to_date('17/12/1980','dd/mm/rrrr'));

  spt_ed:=subT_DEPT(20,'RESEARCH','DALLAS');
  
  OutPutPrint(spt_emp1);
  OutPutPrint(spt_emp2);
  OutPutPrint(spt_emp3);
  OutPutPrint(spt_ed);
  
---  DBMS_OUTPUT.PUT_LINE(spt_emp1.sal); this will give error

  DBMS_OUTPUT.PUT_LINE('Use of treat : treat(spt_emp1 as subt_emp).sal ='||treat(spt_emp1 as subt_emp).sal);

END;  
  
