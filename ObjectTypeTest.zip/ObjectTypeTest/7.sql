--- Super type   (eg. employee)
CREATE OR REPLACE TYPE supertype_emp AS OBJECT
  (  empno NUMBER,
     MEMBER FUNCTION print RETURN VARCHAR2
  )
  NOT FINAL NOT INSTANTIABLE;

---- Sub type (eg. employee)
CREATE OR REPLACE TYPE subt_emp UNDER supertype_emp
(ename varchar2(100),
deptno number,
sal    number,
OVERRIDING MEMBER FUNCTION print RETURN VARCHAR2
);
---- Sub type (eg. employee )
CREATE OR REPLACE TYPE SUBT_EMP_DEPT under supertype_emp
(ename varchar2(100),
 dname varchar2(100),
 comm  number,
 hiredate date ,
 OVERRIDING MEMBER FUNCTION print RETURN VARCHAR2
 );
--- Super type   (eg. Dept)
CREATE OR REPLACE TYPE superT_dept as OBJECT 
(deptno number,
member function display RETURN VARCHAR2
)  NOT FINAL NOT INSTANTIABLE;
--- Sub type   (eg. Dept)
CREATE OR REPLACE TYPE subT_DEPT UNDER superT_dept 
(DNAME varchar2(100),
 loc   varchar2(100)
 OVERRIDING MEMBER FUNCTION display RETURN VARCHAR2
);
-------------------------------------------------------------------------------------------------
-----------------TYPE BODY -------------------------------------

---- Sub type (eg. employee)
CREATE OR REPLACE TYPE BODY subt_emp AS
OVERRIDING MEMBER FUNCTION print RETURN VARCHAR2 IS
     BEGIN
       RETURN '[subt_emp] '     ||self.empno||','||
               TO_CHAR(SELF.ename) || ',' ||
               TO_CHAR(SELF.deptno) || ',' ||
               SELF.sal;
     END;
 END;
 
 ---- Sub type (eg. employee )
CREATE OR REPLACE TYPE BODY SUBT_EMP_DEPT AS
  OVERRIDING MEMBER FUNCTION print RETURN VARCHAR2 IS
     BEGIN
          RETURN '[SUBT_EMP_DEPT] :['||self.empno||']['||SELF.ename||'][ '||SELF.dname||'][ '||SELF.comm ||'][ '||SELF.hiredate||']';
     END;
END;

--- Sub type   (eg. Dept)
CREATE OR REPLACE TYPE BODY subT_DEPT AS
 OVERRIDING MEMBER FUNCTION display RETURN VARCHAR2 IS
  BEGIN
    return '[subT_DEPT]'||self.DNAME ||' '||self.loc   ;
  END;
END;  

