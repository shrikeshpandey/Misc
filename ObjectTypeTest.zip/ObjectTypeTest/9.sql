CREATE TYPE superTabtyp_emp AS table of supertype_emp;
CREATE TYPE superTabtyp_dept AS table of superT_dept;
