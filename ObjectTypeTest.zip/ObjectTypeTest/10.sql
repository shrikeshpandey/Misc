CREATE OR REPLACE FUNCTION func_emp RETURN superTabtyp_emp PIPELINED AS
  BEGIN
     PIPE ROW (subt_emp(7369,'SMITH',20,800));
     PIPE ROW (SUBT_EMP_DEPT(7368,'SMITH','RESEARCH',NULL,to_date('17/12/1980','dd/mm/rrrr')));
     PIPE ROW (SUBT_EMP_DEPT(7366,'SMITH','RESEARCH',NULL,to_date('17/12/1980','dd/mm/rrrr')));
     RETURN;
  END func_emp;
/
SELECT t.*  FROM   TABLE(func_emp) t;

/
SELECT VALUE(t)  FROM TABLE(func_emp) t;

/
CREATE or replace VIEW v1  AS
     SELECT VALUE(t) AS o
     FROM   TABLE(func_emp) t;

/
select * from v1
/
SELECT *
  FROM   v1
  WHERE  o IS OF TYPE (subt_emp);
/
SELECT *
  FROM   v1
  WHERE  o IS OF (ONLY SUBT_EMP_DEPT);
/
SELECT SYS_TYPEID(o) AS type_id
  ,      o             AS object_instance
  FROM   v1;
/
SELECT TREAT(o AS SUBT_EMP_DEPT) AS treated_subtype
  FROM   v1
  WHERE  o IS OF (ONLY SUBT_EMP_DEPT);
  /
SELECT TREAT(o AS subt_emp) AS treated_subtype
  FROM   v1
  WHERE  o IS OF (ONLY subt_emp);  
/
SELECT TREAT(o AS subt_emp).empno AS empno
    ,TREAT(o AS subt_emp).ename AS ename
    ,TREAT(o AS subt_emp).deptno AS deptno
    ,TREAT(o AS subt_emp).sal as sal
    FROM   v1
    WHERE  o IS OF TYPE (subt_emp);







