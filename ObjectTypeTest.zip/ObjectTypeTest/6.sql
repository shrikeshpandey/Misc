create table t_emp
(te_id NUMBER,
 te_emp_col typ_emp);
 
   SELECT ROWNUM
    ,      typ_emp(empno,ename,job,mgr,HIREDATE,SAL,COMM,e.deptno )
    FROM   emp e;

/
INSERT INTO t_emp
   SELECT ROWNUM
    ,      typ_emp(empno,ename,job,mgr,HIREDATE,SAL,COMM,e.deptno )
    FROM   emp e;
/
select * from t_emp
/
ALTER TYPE typ_emp ADD
       ATTRIBUTE (DNAME VARCHAR2(100))
       CASCADE INCLUDING TABLE DATA
/ 
INSERT INTO t_emp
   SELECT (select max(te_id) from t_emp)+ROWNUM
    ,      typ_emp(empno+1000,ename,job,mgr,HIREDATE,SAL,COMM,e.deptno,d.dname )
    FROM   emp e,dept d
    where e.deptno=d.deptno;
/

UPDATE t_emp te SET te.te_emp_col.DNAME=(select d.dname from dept d where d.deptno=te.te_emp_col.DEPTNO)
where te.te_emp_col.DNAME IS NULL
