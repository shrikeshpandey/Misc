CREATE or replace TYPE employee_typ AS OBJECT (
 name    VARCHAR2(30 char),
 job_id  VARCHAR2(10),
 phone   VARCHAR2(20) );
 
 CREATE or replace TYPE location_typ AS OBJECT (
postal_code NUMBER,
city VARCHAR2(40) );

CREATE or replace TYPE office_typ AS OBJECT (
    office_id VARCHAR(10),
    office_loc location_typ,
    occupant employee_typ );
    
CREATE TABLE office_tab OF office_typ (
       office_id PRIMARY KEY );    
       
-------Creating the department_mgrs Table with Multiple Constraints
CREATE TABLE department_mgrs (
       dept_no NUMBER PRIMARY KEY,
       dept_name CHAR(20),
       dept_mgr employee_typ,
       dept_loc location_typ,
       CONSTRAINT dept_loc_cons1
                  UNIQUE (dept_loc.postal_code, dept_loc.city),
                  CONSTRAINT dept_loc_cons2
                  CHECK (dept_loc.city IS NOT NULL) );

INSERT INTO department_mgrs VALUES
( 101, 'Physical Sciences',
employee_typ('Vrinda Mills',65, '18005554412'),
location_typ(300, 'Palo Alto'));     


INSERT INTO department_mgrs --VALUES
( SELECT d.department_id,d.department_name,employee_typ(e.first_name||' '||e.last_name,e.job_id,e.phone_number) 
,location_typ(l.postal_code,l.city)
from  employees e,departments d,locations l
where e.department_id=d.department_id
and d.location_id=l.location_id
and postal_code not in ('YSW 9T2','M5V 2L7','3029SK','OX9 9ZB'));   
