CREATE TYPE person_typ AS OBJECT (
idno NUMBER,
name VARCHAR2(30),
phone VARCHAR2(20),
MAP MEMBER FUNCTION get_idno RETURN NUMBER,
MEMBER PROCEDURE display_details ( SELF IN OUT NOCOPY person_typ ) );


CREATE TYPE BODY person_typ AS
MAP MEMBER FUNCTION get_idno RETURN NUMBER IS
BEGIN
RETURN idno;
END;
MEMBER PROCEDURE display_details ( SELF IN OUT NOCOPY person_typ ) IS
BEGIN
-- use the PUT_LINE procedure of the DBMS_OUTPUT package to display details
DBMS_OUTPUT.PUT_LINE(TO_CHAR(idno) || ' - ' || name || ' - ' || phone);
END;
END;


CREATE TABLE contacts (
contact person_typ,
contact_date DATE );

---Inserting NULLs for Objects in a Table
INSERT INTO contacts VALUES (person_typ (NULL, NULL, NULL), '24 Jun 2003' );

INSERT INTO contacts 
(SELECT person_typ (e.employee_id,e.first_name||' '||e.last_name,e.phone_number ), e.hire_date from employees e)
---Inserting NULLs for Objects in a Table
INSERT INTO contacts VALUES (
NULL, '24 Jun 2003' );
select * from contacts;
