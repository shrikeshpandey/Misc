CREATE TABLE t_emp1
  ( number_column NUMBER
  , typ_emp1_col typ_emp1  );

/
  SELECT ROWNUM
    ,      typ_emp1(empno,ename,job,mgr,HIREDATE,SAL,COMM,deptno )
    FROM   emp

/
INSERT INTO t_emp1
     SELECT ROWNUM
    ,      typ_emp1(empno,ename,job,mgr,HIREDATE,SAL,COMM,deptno )
    FROM   emp
/
select * from t_emp1
/
