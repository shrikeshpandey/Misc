/*
File: Object_Ref.sql

Database Package: OBJECT_REF

Note: Requires GRANT SELECT ON SYS."_CURRENT_EDITION_OBJ" TO <defining-schema>. 

*/

create or replace package Object_Ref
authid definer
as
	-- Functions

	function getTableNameFromRef(
		aRefAsHex	in		varchar2
	)
	return varchar2
	deterministic;

	function getSystemOIDFromRef(
		aRefAsHex	in		varchar2
	)
	return raw
	deterministic;

	function getKeyValuesFromRef(
		aRefAsHex	in		varchar2
	)
	return raw
	deterministic;

	function getKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return raw
	deterministic;

	function getNumberKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return number
	deterministic;

	function getStringKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return varchar2
	deterministic;

	function getDateKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return date
	deterministic;

	function getTimestampKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return timestamp
	deterministic;

	function getKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return raw
	deterministic;

	function getNumberKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return number
	deterministic;

	function getStringKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return varchar2
	deterministic;

	function getDateKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return date
	deterministic;

	function getTimestampKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return timestamp
	deterministic;

	function castToDate(
		aKeyValue	in		raw
	)
	return date
	deterministic;

	function castToTimestamp(
		aKeyValue	in		raw
	)
	return timestamp
	deterministic;

	function appendKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		raw
	)
	return raw
	deterministic;

	function appendNumberKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		number
	)
	return raw
	deterministic;

	function appendStringKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		varchar2
	)
	return raw
	deterministic;

	function appendDateKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		date
	)
	return raw
	deterministic;

	function appendTimestampKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		timestamp
	)
	return raw
	deterministic;

	function castFromDate(
		aValue		in		date
	)
	return raw
	deterministic;

	function castFromTimestamp(
		aValue		in		timestamp
	)
	return raw
	deterministic;

end;
/
