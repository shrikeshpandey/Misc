define on

--
-- Installation directory. Default is working directory
--
define INSTALL_DIR = "."

@@"&INSTALL_DIR\Object_Ref.sql"
@@"&INSTALL_DIR\Object_Ref.body.sql"
