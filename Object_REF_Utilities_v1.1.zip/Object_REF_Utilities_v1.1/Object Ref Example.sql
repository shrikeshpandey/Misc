create or replace type TNodeObject
is object
(
	parentNode	ref TNodeObject
,	name		varchar2(200)
)
/

create
table	T_NODE_OBJECT
(
	parentNodeName	varchar2(200)
,	name		varchar2(200)	not null
,	primary key (
		name
	)
,	foreign key (
		parentNodeName
	)
	references T_NODE_OBJECT
)
organization
	index
/

create or replace view V_NODE_OBJECT
of TNodeObject
with object identifier (name)
as
select	new TNodeObject(
		null
	,	'temp'
	)
from	DUAL
where	1 = 0
/

create or replace view V_NODE_OBJECT
of TNodeObject
with object identifier (name)
as
select	new TNodeObject(
		case
		when t.parentNodeName is not null then
			make_ref(V_NODE_OBJECT, t.parentNodeName)
		end
	,	t.name
	)
from	T_NODE_OBJECT t
/

create or replace trigger TR_II_NODE_OBJECT
instead of insert
on V_NODE_OBJECT
begin
	insert
	into	T_NODE_OBJECT
	(
		parentNodeName
	,	name
	)
	select	deref(:new.parentNode).name
	,	:new.name
	from	DUAL;
end;
/

insert
into	V_NODE_OBJECT
select	new TNodeObject(
		null
	,	'Node1'
	)
from	DUAL
/

insert
into	V_NODE_OBJECT
select	new TNodeObject(
		ref(p)
	,	'Node2'
	)
from	V_NODE_OBJECT p
where	p.name = 'Node1'
/

insert
into	V_NODE_OBJECT
select	new TNodeObject(
		ref(p)
	,	'Node3'
	)
from	V_NODE_OBJECT p
where	p.name = 'Node2'
/

select	lpad(' ', 2 * (level - 1)) || v.name
from	V_NODE_OBJECT v
start with
	v.parentNode is null
connect by
	v.parentNode = prior ref(v)
/

rollback
/

create or replace trigger TR_II_NODE_OBJECT
instead of insert
on V_NODE_OBJECT
begin
	insert
	into	T_NODE_OBJECT
	(
		parentNodeName
	,	name
	)
	values
	(
		OBJECT_REF.getStringKeyValueFromRef(reftohex(:new.parentNode))
	,	:new.name
	);
end;
/

insert
into	V_NODE_OBJECT
select	new TNodeObject(
		null
	,	'Node1'
	)
from	DUAL
/

insert
into	V_NODE_OBJECT
select	new TNodeObject(
		ref(p)
	,	'Node2'
	)
from	V_NODE_OBJECT p
where	p.name = 'Node1'
/

insert
into	V_NODE_OBJECT
select	new TNodeObject(
		ref(p)
	,	'Node3'
	)
from	V_NODE_OBJECT p
where	p.name = 'Node2'
/

select	lpad(' ', 2 * (level - 1)) || v.name
from	V_NODE_OBJECT v
start with
	v.parentNode is null
connect by
	v.parentNode = prior ref(v)
/

commit
/

create or replace trigger TR_IU_NODE_OBJECT
instead of update
on V_NODE_OBJECT
begin
	update	T_NODE_OBJECT t
	set	t.parentNodeName = deref(:new.parentNode).name
	where	t.name = :old.name;
end;
/

update	V_NODE_OBJECT v
set	v.parentNode = (
		select	ref(p)
		from	V_NODE_OBJECT p
		where	p.name = 'Node1'
	)
where	v.name = 'Node3'
/

rollback
/

create or replace trigger TR_IU_NODE_OBJECT
instead of update
on V_NODE_OBJECT
begin
	update	T_NODE_OBJECT t
	set	t.parentNodeName = OBJECT_REF.getStringKeyValueFromRef(reftohex(:new.parentNode))
	where	t.name = :old.name;
end;
/

update	V_NODE_OBJECT v
set	v.parentNode = (
		select	ref(p)
		from	V_NODE_OBJECT p
		where	p.name = 'Node1'
	)
where	v.name = 'Node3'
/

select	lpad(' ', 2 * (level - 1)) || v.name
from	V_NODE_OBJECT v
start with
	v.parentNode is null
connect by
	v.parentNode = prior ref(v)
/
