--------------------------------
Author Name			Gerard Averill
Author's e-mail			gaverill@chsra.wisc.edu
 
Title				PL/SQL Object Ref Utilities
Sample Type			example code  
Code sample version		1.1

What it does			This sample demonstrates techniques (HACKS!) for manipulating SQL object type references (REFs).
How it Works			This sample creates a package which can extract information from a REF without dereferencing it.
How to install and execute 	See the install instructions in the readme file included with the code sample.
--------------------------------

---------------------
What's New in v1.1:
---------------------

Modified Object_Ref package to require SELECT privileges on SYS."_CURRENT_EDITION_OBJ" rather than SYS.KU$_EDITION_OBJ_VIEW.

Modified Object_Ref.getTableNameFromRef to handle REFs to object table rows with system-generated OIDs.

Added Object_Ref.getSystemOIDFromRef, which extracts the 16-byte raw OID from a REF to an object table with system-generated OIDs.

Modified Object_Ref.getKeyValuesFromRef to handle REFs to object table rows with system-generated OIDs.

Fixed Object_Ref.appendKeyValue to correctly append a key value whose length is less than 256 bytes.

---------------------
Included Files:
---------------------

	Object_Ref.sql			OBJECT_REF package specification
	Object_Ref.body.sql		OBJECT_REF package body

	Readme.txt			This readme file
	Install.sql			Simple script to install the sample code into the current schema
	Object Ref Example.sql		Example script demonstrating the use of OBJECT_REF package to workaround mutating table errors in object view INSTEAD-OF triggers.
	Object Ref Example Output.txt	Output from 'Object Ref Example.sql' script

---------------------
Install Instructions:
---------------------

1) Login to Oracle using SQL*Plus or other tool. Ensure that the current user has CREATE PROCEDURE privileges in order to install the sample code.

3) Copy the Install.sql script into SQL*Plus, modifying the INSTALL_DIR substitution variable definition as necessary to point to the directory containing the included files.

4) Run the script.

---------------------
Using the Sample Code
---------------------

Please note that this version of OBJECT_REF has only been tested in Oracle versions 10 and 11 for Windows.

The internal representation of object REFs may be platform-specific. However, interested users of other versions and platforms may find this implementation a useful starting point for developing other platform-specific versions.

The OBJECT_REF package is designed to work with references to object tables (with both system-generated and primary-key-based OIDs) and view rows.

The 'Object Ref Example.sql' script demonstrates how being able to extract primary key values directly from an object REF without dereferencing can be used to workaround mutating table errors in INSTEAD-OF triggers for self-referencing object views.
