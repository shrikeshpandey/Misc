/*
OBJECT_REF
*/

create or replace package body Object_Ref
as
	-- Package private declarations

	SYSTEM_GENERATED	constant varchar2(2)	:= '09';	-- Object table w/ system generated OIDs
	PK_OR_TOP_LEVEL_VIEW	constant varchar2(2)	:= '8A';	-- Object table w/ primary key-based OIDs, or top-level object views
	ITS_MAGIC_TO_ME		constant varchar2(6)	:= '8401FE';	-- Start of encoded key values block

	-- Package public functions

	function getTableNameFromRef(
		aRefAsHex	in		varchar2
	)
	return varchar2
	is
		tableOID	raw(16);
		result		varchar2(65);
	begin
		if aRefAsHex is not null then
			case substr(aRefAsHex, 9, 2)
			when SYSTEM_GENERATED then
				tableOID := hextoraw(substr(aRefAsHex, 43, 32));
			when PK_OR_TOP_LEVEL_VIEW then
				tableOID := hextoraw(substr(aRefAsHex, 15, 32));
			else
				tableOID := hextoraw(substr(aRefAsHex, -32));
			end case;

			select	decode(u.USERNAME, upper(u.USERNAME), u.USERNAME, '"' || u.USERNAME || '"')
			||	'.'
			||	decode(o.NAME, upper(o.NAME), o.NAME, '"' || o.NAME || '"')
			into	result
			from	SYS."_CURRENT_EDITION_OBJ" o
			,	SYS.ALL_USERS u
			where	o.OID$ = tableOID
			and	u.USER_ID = o.OWNER#;
		end if;

		return	result;
	end;

	function getSystemOIDFromRef(
		aRefAsHex	in		varchar2
	)
	return raw
	is
	begin
		return	case
			when aRefAsHex is not null then
				hextoraw(substr(aRefAsHex, 11, 32))
			end;
	end;

	function getKeyValuesFromRef(
		aRefAsHex	in		varchar2
	)
	return raw
	is
		pos		pls_integer;
		len		pls_integer;
	begin
		if aRefAsHex is not null then
			if substr(aRefAsHex, 9, 2) = SYSTEM_GENERATED then
				return	appendKeyValue(null, getSystemOIDFromRef(aRefAsHex));
			end if;

			pos := instr(aRefAsHex, ITS_MAGIC_TO_ME);

			if pos > 0 then
				-- Total length of all keys, from start of ITS_MAGIC_TO_ME, in next 4 bytes

				len := UTL_RAW.Cast_To_Binary_Integer(hextoraw(substr(aRefAsHex, pos + length(ITS_MAGIC_TO_ME), 8))) * 2;

				return	hextoraw(substr(aRefAsHex, pos + length(ITS_MAGIC_TO_ME) + 8, len - length(ITS_MAGIC_TO_ME) - 8));
			end if;
		end if;

		return	null;
	end;

	function getKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return raw
	is
	begin
		return	getKeyValue(getKeyValuesFromRef(aRefAsHex), aKeyIndex);
	end;

	function getNumberKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return number
	is
	begin
		return	getNumberKeyValue(getKeyValuesFromRef(aRefAsHex), aKeyIndex);
	end;

	function getStringKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return varchar2
	is
	begin
		return	getStringKeyValue(getKeyValuesFromRef(aRefAsHex), aKeyIndex);
	end;

	function getDateKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return date
	is
	begin
		return	getDateKeyValue(getKeyValuesFromRef(aRefAsHex), aKeyIndex);
	end;

	function getTimestampKeyValueFromRef(
		aRefAsHex	in		varchar2
	,	aKeyIndex	in		integer			:= 1
	)
	return timestamp
	is
	begin
		return	getTimestampKeyValue(getKeyValuesFromRef(aRefAsHex), aKeyIndex);
	end;

	function getKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return raw
	is
		len	constant pls_integer	:= UTL_RAW.Length(aKeyValues);
		pos	pls_integer		:= 1;
		idx	pls_integer		:= aKeyIndex;

		keyLen	pls_integer;
	begin
		while pos < len and idx > 0
		loop
			if UTL_RAW.Substr(aKeyValues, pos, 2) = 'FE' then
				-- 'FE' followed by key length in next 4 bytes

				keyLen	:= UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValues, pos + 1, 4));
				pos	:= pos + 1 + 4;
			else
				-- Key length in next byte

				keyLen	:= UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValues, pos, 1));
				pos	:= pos + 1;
			end if;

			if idx = 1 then
				return	UTL_RAW.Substr(aKeyValues, pos, keyLen);
			end if;

			pos	:= pos + keyLen;
			idx	:= idx - 1;
		end loop;

		return	null;
	end;

	function getNumberKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return number
	is
	begin
		return	UTL_RAW.Cast_To_Number(getKeyValue(aKeyValues, aKeyIndex));
	end;

	function getStringKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return varchar2
	is
	begin
		return	UTL_RAW.Cast_To_Varchar2(getKeyValue(aKeyValues, aKeyIndex));
	end;

	function getDateKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return date
	is
	begin
		return	castToDate(getKeyValue(aKeyValues, aKeyIndex));
	end;

	function getTimestampKeyValue(
		aKeyValues	in		raw
	,	aKeyIndex	in		integer			:= 1
	)
	return timestamp
	is
	begin
		return	castToTimestamp(getKeyValue(aKeyValues, aKeyIndex));
	end;

	function castToDate(
		aKeyValue	in		raw
	)
	return date
	is
	begin
		-- See: http://www.ixora.com.au/notes/date_representation.htm

		return	case
			when aKeyValue is not null then
				to_date(
					to_char(
						100 * (UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 1, 1)) - 100)
					+	UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 2, 1)) - 100
					)
					||	'/'
					||	to_char(UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 3, 1)))
					||	'/'
					||	to_char(UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 4, 1)))
					||	' '
					||	to_char(UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 5, 1)) - 1)
					||	':'
					||	to_char(UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 6, 1)) - 1)
					||	':'
					||	to_char(UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 7, 1)) - 1)
				,	'yyyy/mm/dd hh24:mi:ss'
				)
			end;
	end;

	function castToTimestamp(
		aKeyValue	in		raw
	)
	return timestamp
	is
		len	binary_integer	:= UTL_RAW.Length(aKeyValue);
	begin
		return	case
			when aKeyValue is not null then
				to_timestamp(
					to_char(
						OBJECT_REF.castToDate(aKeyValue)
					,	'yyyy/mm/dd hh24:mi:ss'
					)
					||	case
						when len >= 8 then
							trim(leading '0' from to_char(UTL_RAW.Cast_To_Binary_Integer(UTL_RAW.Substr(aKeyValue, 8)) / power(10, 9)))
						end
				,	'yyyy/mm/dd hh24:mi:ss.ff'
				)
			end;
	end;

	function appendKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		raw
	)
	return raw
	is
		len	binary_integer	:= UTL_RAW.Length(aKeyValue);
	begin
		return	UTL_RAW.Concat(
				aKeyValues
			,	case
				when len < 256 then
					UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(len), -1)
				else
					UTL_RAW.Concat(
						hextoraw('FE')
					,	UTL_RAW.Cast_From_Binary_Integer(len)
					)
				end
			,	aKeyValue
			);
	end;

	function appendNumberKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		number
	)
	return raw
	is
	begin
		return	appendKeyValue(aKeyValues, UTL_RAW.Cast_From_Number(aKeyValue));
	end;

	function appendStringKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		varchar2
	)
	return raw
	is
	begin
		return	appendKeyValue(aKeyValues, UTL_RAW.Cast_To_Raw(aKeyValue));
	end;

	function appendDateKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		date
	)
	return raw
	is
	begin
		return	appendKeyValue(aKeyValues, castFromDate(aKeyValue));
	end;

	function appendTimestampKeyValue(
		aKeyValues	in		raw
	,	aKeyValue	in		timestamp
	)
	return raw
	is
	begin
		return	appendKeyValue(aKeyValues, castFromTimestamp(aKeyValue));
	end;

	function castFromDate(
		aValue		in		date
	)
	return raw
	is
	begin
		return	case
			when aValue is not null then
				UTL_RAW.Substr(castFromTimestamp(aValue), 1, 7)
			end;
	end;

	function castFromTimestamp(
		aValue		in		timestamp
	)
	return raw
	is
		yr	binary_integer	:= extract(year from aValue);
	begin
		return	case
			when aValue is not null then
				UTL_RAW.Concat(
					UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(trunc(yr / 100) + 100), -1)
				,	UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(mod(yr, 100) + 100), -1)
				,	UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(extract(month from aValue)), -1)
				,	UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(extract(day from aValue)), -1)
				,	UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(extract(hour from aValue) + 1), -1)
				,	UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(extract(minute from aValue) + 1), -1)
				,	UTL_RAW.Substr(UTL_RAW.Cast_From_Binary_Integer(extract(second from aValue) + 1), -1)
				,	UTL_RAW.Cast_From_Binary_Integer(to_number('0.' || to_char(aValue, 'FF')) * power(10, 9))
				)
			end;
	end;

end;
/
