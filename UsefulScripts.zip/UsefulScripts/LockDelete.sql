begin
  
  for i in (select distinct  vs.SID,vs.SERIAL# from v$session vs ,v$lock vl
where  vs.SID=vl.SID
and vs.OSUSER not in ('INFOTECH\51221')) loop

begin
execute immediate 'alter system kill session '||''''||i.sid||','||i.serial#||'''';
exception
  when others then
    null;
end;    
end loop;
end;
