/* By Shrikesh */
DECLARE
   l_table_name   cat.table_name%TYPE;
   l_sql          VARCHAR2 (2000);
   l_cnt          NUMBER;
BEGIN
   DBMS_OUTPUT.put_line (RPAD (' ', 60, '-'));
   DBMS_OUTPUT.put_line (RPAD ('TABLE_NAME', 50) || 'COUNT');
   DBMS_OUTPUT.put_line (RPAD (' ', 60, '-'));

   FOR i IN (  SELECT table_name, table_type
                 FROM cat
                WHERE table_type = 'TABLE'
             ORDER BY table_name)
   LOOP
   BEGIN
      l_sql := 'SELECT count(*) from ' || i.table_name;

      EXECUTE IMMEDIATE l_sql INTO l_cnt;
      
	  IF l_cnt>10000 THEN
      
      EXECUTE IMMEDIATE 'ANALYZE TABLE '||i.table_name||' compute statistics';
      
	  end if;
      
      DBMS_OUTPUT.put_line (RPAD (i.table_name, 50) || l_cnt);
   
   
   EXCEPTION
   WHEN OTHERS THEN 
   dbms_output.put_line('Error :'||i.table_name ||'  '||SQLCODE||':  '||SQLERRM);
   
   END;
   END LOOP;
END;

