DECLARE

l_obj_name      VARCHAR2(2000);
l_obj_type      VARCHAR2(2000);
l_obj_ddl       CLOB;

begin


for k in (SELECT 'select '||''''||object_name||''','''||object_type||''''||','||'dbms_metadata.get_ddl('''||object_type||''','''||object_name 
                 ||''','''||owner||''')' || 'from dual' sqlscr from all_objects
                  where OWNER='TANGIBLE'
                  AND object_name NOT LIKE 'BIN%'
                    and OBJECT_TYPE in ('INDEX','PACKAGE','PROCEDURE','SEQUENCE','SYNONYM','TABLE','TRIGGER','TYPE','VIEW')
                  order by object_type)
LOOP



execute immediate k.sqlscr into l_obj_name ,l_obj_type,l_obj_ddl;
dbms_output.put_line('REM  Object Name  '||l_obj_name||'  Object Type   '||l_obj_type);
dbms_output.put_line(l_obj_ddl);

INSERT INTO SSP VALUES (l_obj_name ,l_obj_type,l_obj_ddl);

END LOOP;

end ;

